################################################################################
#      This file is part of OpenELEC - http://www.openelec.tv
#      Copyright (C) 2009-2014 Stephan Raue (stephan@openelec.tv)
#
#  OpenELEC is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 2 of the License, or
#  (at your option) any later version.
#
#  OpenELEC is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with OpenELEC.  If not, see <http://www.gnu.org/licenses/>.
################################################################################
import xbmc, xbmcgui, xbmcplugin, xbmcaddon
import os

import util, simplelauncher

ADDON_ID = 'emulator.tools.retroarch'

addon = xbmcaddon.Addon(id=ADDON_ID)
addon_dir = xbmc.translatePath( addon.getAddonInfo('path') )
addonfolder = addon.getAddonInfo('path')

icon    = addonfolder + '/icon.png'
fanart  = addonfolder + '/fanart.jpg'


# Get Settings
#USER_AGENT = addon.getSetting('user_agent')
USER_AGENT = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/32.0.1700.107 Safari/537.36"
#THUMBNAIL_SIZE = addon.getSetting('thumbnail_size')
THUMBNAIL_SIZE = '300'

# Parse parameters
parameters = util.parseParameters()

#print ">>> Parameters: " + str(parameters)
#print ">>> sys.argv[0]: " + str(sys.argv[0])
#print ">>> sys.argv[1]: " + str(sys.argv[1])
#print ">>> sys.argv[2]: " + str(sys.argv[2])

if 'r' in parameters:
    simplelauncher.playGame(USER_AGENT, parameters)
elif 'f' in parameters:
    simplelauncher.listGames(USER_AGENT, THUMBNAIL_SIZE, parameters, fanart, addon.getLocalizedString(30005))
else:
    simplelauncher.buildMenu(USER_AGENT, fanart, addon.getLocalizedString(30004))
# Ends list of items for xbmc
util.endListing()


