import sys, urllib, urllib2
import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import util
import re, os


WEB_PAGE_BASE='http://tv.estadao.com.br'
SEARCH_URL_BEGIN='http://tv.estadao.com.br/videos-busca?q='
SEARCH_URL_END=''
THUMB_URL_BEGIN='/thumbs/'
THUMB_URL_END='/resources/jpg/'
XML_URL_BEGIN='http://front.multimidia.estadao.com.br/ESTA/swf/data/pt/video-player/video/'
SWF_URL='http://front.multimidia.estadao.com.br/ESTA/swf/ACTPlayer.swf'
PAGE_NUM_PARAM_BEGIN='pagina='
PAGE_NUM_PARAM_END= '#maisVideos'

BASE_URL="plugin://emulator.tools.retroarch"

 
def buildMenu(user_agent, fanart=None, searchString='SEARCH'):
     
     if util.getConfig("core_1_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_1_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_1_lib"))
          myParam['l'] = util.getConfig("core_1_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_1_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_2_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_2_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_2_lib"))
          myParam['l'] = util.getConfig("core_2_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_2_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_3_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_3_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_3_lib"))
          myParam['l'] = util.getConfig("core_3_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_3_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_4_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_4_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_4_lib"))
          myParam['l'] = util.getConfig("core_4_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_4_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_5_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_5_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_5_lib"))
          myParam['l'] = util.getConfig("core_5_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_5_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_6_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_6_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_6_lib"))
          myParam['l'] = util.getConfig("core_6_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_6_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_7_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_7_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_7_lib"))
          myParam['l'] = util.getConfig("core_7_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_7_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_8_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_8_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_8_lib"))
          myParam['l'] = util.getConfig("core_8_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_8_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_9_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_9_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_9_lib"))
          myParam['l'] = util.getConfig("core_9_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_9_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_10_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_10_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_10_lib"))
          myParam['l'] = util.getConfig("core_10_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_10_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_11_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_11_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_11_lib"))
          myParam['l'] = util.getConfig("core_11_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_11_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_12_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_12_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_12_lib"))
          myParam['l'] = util.getConfig("core_12_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_12_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_13_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_13_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_13_lib"))
          myParam['l'] = util.getConfig("core_13_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_13_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_14_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_14_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_14_lib"))
          myParam['l'] = util.getConfig("core_14_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_14_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)

     if util.getConfig("core_15_lib"):
          myParam = {}
          myParam['f'] = util.getConfig("core_15_folder")
          myParam['c'] = util.getCoreName(util.getConfig("core_15_lib"))
          myParam['l'] = util.getConfig("core_15_lib")
          print ">>>>>> myParam: " + str(myParam)
          util.addMenuItem(util.getCoreName(util.getConfig("core_15_lib")), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)




	 
def listGames(user_agent, thumbnail_size, params, fanart=None, my_string=None):
    emu_core = params['c']
    roms_folder = params['f']
    pattern = ".*\..*"
	
    #regexObj = re.compile(".*\.so")
    for root, dirs, files in os.walk(roms_folder, topdown=False):
        for file in filter(lambda x: re.match(pattern, x), files):
            myParam = {}
            myParam['c'] = emu_core
            myParam['r'] = os.path.join(roms_folder,str(file))
            util.addMenuItem(str(file), util.makeLink(myParam), icon=None, thumbnail=None, folder=True, fanart=fanart)
	

def playGame(user_agent, params):
    emu_core = params['c']
    rom_file = params['r']
    util.runEmulator(emu_core, rom_file)
    


