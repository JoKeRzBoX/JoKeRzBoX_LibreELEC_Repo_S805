XMB Dot-art Theme
====================


Most icons are made by "Yoshi-kun", a Japanese author, from his website:
http://yspixel.jpn.org/icon/index.html

You can find his collection in the src folder, resized to 256x256 to avoid any kind of filtering happenning in the menu.

The other ones are made by Tatsuya79, some are just slightly altered version of Yoshi-kun ones or 
from various sources.

Ideally they should be drawn in 32x32 pixels then resized to 256x256.

Icons not covered yet are taken from the Monochrome theme.